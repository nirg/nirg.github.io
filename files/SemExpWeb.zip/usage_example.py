import semexpweb

if __name__ == '__main__':
	coffee_terms = ['coffee', '#coffee', 'starbucks', '#starbucks', 'espresso', '#espresso', 'lovecoffee', '#lovecoffee', 'caffeineaddict', '#caffeineaddict', 'venti', '#venti', 'starbucks', '#starbucks', 'mugs', '#mugs', 'latte', '#latte', 'caf', '#caf', 'coffeebean', '#coffeebean']
	c = semexpweb.Client(server='23.22.67.45')
	print c.context_pmi(coffee_terms)