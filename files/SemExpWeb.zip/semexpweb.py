import urllib, httplib

def import_json():
	try:
		import ujson as json
	except ImportError:
		try:
			import simplejson as json
		except ImportError:
			try:
				import json  # Python 2.6+
			except ImportError:
				try:
					from django.utils import simplejson as json  # Google App Engine
				except ImportError:
					raise ImportError, "Can't load a json library"
	return json
json = import_json()

class Client(object):
	def __init__(self, server='127.0.0.1', port=8642, timeout=60):
		self._server = server
		self._port = port
		self._timeout = 60

	def _execute_get(self, path, parameters={}, headers={}):
		url = '/%s' % path
		if len(parameters)>0:
			url = '%s?%s' % (url, urllib.urlencode(parameters))
		conn = httplib.HTTPConnection(self._server, port=self._port, timeout=self._timeout)
		conn.request('GET', url, headers=headers)
		resp = conn.getresponse()

		if resp.status != 200:
			raise Exception('Error code %d: %s' % (resp.status, resp.reason))

		return resp.read()

	def agg_pmi(self, terms, top_n=100):
		"""
		Expand the provided terms list using aggregated pmi method. Returns a list pairs of expanded term and its score.
		Input:
			terms - a list of strings to use as seed list for the expanded list.
			top_n - optional integer, specificying how many terms would be returned.
		Output:
			[[term, score], ...] - list of top_n terms and their scores sorted in descending order.
		"""
		parameters = {'terms': u','.join([w.encode('utf-8') for w in terms]), 'top_n': top_n}
		return json.loads(self._execute_get('agg_pmi', parameters))

	def context_pmi(self, terms='', freq_cutoff=None, bootstrap_samples=100, score_cutoff=500):
		"""
		Expand the provided terms list using context pmi method. Returns a list pairs of expanded term and its score.
		Input:
			terms - a list of strings to use as seed list for the expanded list.
			freq_cutoff - minimum document frequency of returned terms.
			bootstrap_samples - optional integer, number of times to bootstrap the seed list in building the context for the method.
			score_cutoff - optional integer, specificying the minimum score for returned terms.
		Output:
			[[term, score], ...] - list of terms and their scores sorted in descending order.
		"""
		parameters = {'terms': u','.join([w.encode('utf-8') for w in terms]), 'bootstrap_samples':bootstrap_samples, 'score_cutoff':score_cutoff}
		if freq_cutoff is not None:
			parameters['freq_cutoff'] = freq_cutoff
		return json.loads(self._execute_get('context_pmi', parameters))